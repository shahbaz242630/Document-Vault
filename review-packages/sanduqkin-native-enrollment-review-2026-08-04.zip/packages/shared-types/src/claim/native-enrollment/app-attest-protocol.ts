export const APP_ATTEST_REGISTRATION_PROTOCOL_V1 =
  "sanduqkin:claim:native-enrollment:app-attest-registration:v1" as const;
export const APP_ATTEST_ASSERTION_PROTOCOL_V1 =
  "sanduqkin:claim:native-enrollment:app-attest-assertion:v1" as const;
export const APP_ATTEST_KEY_ID_DIGEST_LABEL_V1 =
  "sanduqkin:claim:native-enrollment:app-attest-key-id:v1" as const;
export const APP_ATTEST_CHALLENGE_TTL_SECONDS_V1 = 300 as const;

