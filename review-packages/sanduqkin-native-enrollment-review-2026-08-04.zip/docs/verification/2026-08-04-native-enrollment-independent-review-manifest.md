# Native Enrollment Independent Review Manifest

Date: 2026-08-04 (Asia/Dubai)

## Scope And Identity

This value-free manifest binds the exact runtime-disconnected Slice 1B possession-proof/invitation inputs and Slice 1C App Attest inputs prepared for independent review.

- Base commit: `887abd0459197c5123b8972e1b8c5bed14ec5528`.
- Slice 1B ten-file aggregate SHA-256: `4abdfb3230f96ada853f3ae096c28e8efc282cf5fbadf99e41d081a6780d3100`.
- Slice 1C fifteen-file aggregate SHA-256: `a7bf764d6e4d1cc44175fadde533d73237e198b6e6680b8915b2b833306515cf`.
- Aggregate algorithm: sort the paths for that slice ordinally; SHA-256 each complete file; serialize each as `<lowercase-sha256><two spaces><path>` joined by LF; SHA-256 the UTF-8 serialization.
- Repository state: authoritative in-progress working tree, not an immutable published commit. Review decisions are valid only for these hashes. Any code/vector/test/isolation change requires a new manifest and review delta.

## Exact Files

| Scope | Path | SHA-256 |
|---|---|---|
| 1C | `apps/mobile/src/features/claimant-custody/app-attest-contract.test.ts` | `5b6b19701eb1b82149a397cb138be1e447a93fdad15fe8639152a78a48629617` |
| 1C | `apps/mobile/src/features/claimant-custody/app-attest-contract.ts` | `747d410067984133298fbfa514ead4c9448dbd7735f84cc8af5e652b2538f746` |
| 1C | `packages/shared-types/src/claim/native-enrollment/app-attest-contracts.ts` | `dc60d5e48eb5d996c072e7224f6ed7689a9ccc898930236a2c045f3d3e76b0f1` |
| 1C | `packages/shared-types/src/claim/native-enrollment/app-attest-fixtures.ts` | `c99f31a2a10520ab203ba487d6f269f44f845c112b77431426c5da4d10d2e575` |
| 1C | `packages/shared-types/src/claim/native-enrollment/app-attest-protocol.ts` | `b976890830614814e245153baf45d5066039f2fb430ed2ab8357aad3d6909fc9` |
| 1C | `packages/shared-types/src/claim/native-enrollment/app-attest-validation.test.ts` | `5b92a843e5e1dfe96bb1c6554e3fe7395363c8d55165f3d9211ae3fa65c55207` |
| 1C | `packages/shared-types/src/claim/native-enrollment/app-attest-validation.ts` | `d397c9dac968262a60cd0b1490081daca95e7c597718ccea736acb48fcf1e2dd` |
| 1C | `packages/shared-types/src/claim/native-enrollment/app-attest-vector.test.ts` | `791b1cfb17ffa79dedd1d17dc536bfbf57c87ab536001a02d323b4273e9329e1` |
| 1B | `packages/shared-types/src/claim/native-enrollment/contracts.ts` | `79dd769a135983171e5474f4f8a8dfb9ee8ad1a0210484f151f7d1026835d53e` |
| 1B | `packages/shared-types/src/claim/native-enrollment/fixtures.ts` | `5091a1b2162f6930c7f37cbd6e7f01fdffe111c4c9bb27afea8f501d16eebdd1` |
| 1C | `packages/shared-types/src/claim/native-enrollment/index.ts` | `aaea8cfc4e469ff3e31e093dd839c626713279d00ff2f12f71a12cfd3ff21c05` |
| 1B | `packages/shared-types/src/claim/native-enrollment/possession-proof-vector.test.ts` | `36b7a98ada93f57ef229177fb63bc3e8ba8363c616238fcfb6ae9a91e1c4fbe4` |
| 1B | `packages/shared-types/src/claim/native-enrollment/protocol.ts` | `f9ec5c5779959f125c5a337b8f97322384b66ffcd3feb0794c8b78c8a3646433` |
| 1B | `packages/shared-types/src/claim/native-enrollment/validation.test.ts` | `2168344c378747b57730d060b5881d3f954aff57dbe9c74cfab82dd7a48878fd` |
| 1B | `packages/shared-types/src/claim/native-enrollment/validation.ts` | `aeb376b89846798e9eefa12d5a9f92a1d0ec315155284b5c9cc972084ded8816` |
| 1C | `packages/shared-types/test-vectors/claim/app-attest-binding-v1.json` | `b78657d59f02570e72ff193035db2a3e029d086b1a2eb53defde5b8674833a06` |
| 1B | `packages/shared-types/test-vectors/claim/native-enrollment-proof-v1.json` | `8be528b4916786c64956d684879b22c6ae5962f0d9a6c9ab1607acdabb27e564` |
| 1C | `scripts/claim-custody-isolation-check.cjs` | `d693cb449159c4251750935702ad97469981f8588eddcd8725c8e42d98f227e5` |
| 1C | `scripts/claim-vector-generator/app-attest-binding-vector.mjs` | `dbb4c6a17b7996118f50a12530df3b0a24920d42fa62522c03ec98f91e119a23` |
| 1B | `scripts/claim-vector-generator/native-enrollment-proof-vector.mjs` | `543a285a2fdc4e8360ac1779059141934fb5283fa6db9d05218e4661ac7da6b0` |
| 1C | `scripts/claim-vector-isolation-check.cjs` | `c4dfb9851c174bf432e2476e5479b9d171f0dbb3d4c8b3a05e291c69fdfbf247` |
| 1C | `scripts/generate-claim-test-vectors.mjs` | `55c7424ca2cbde028a0a97ca134570c95e52c92ff22493d339d1de4bd4ba7891` |
| 1C | `services/api/src/claimant/app-attest-contract.test.ts` | `bd1025178bfa131343ce61fe7f289bbd24ed4d8ddeb18fa436c8d0bb41f9493d` |
| 1B | `services/api/src/claimant/invitation-address-v1.test.ts` | `4d17801d04db65a8af9b43d9be891fb76478093e9cdd68791d5e8cb96f24fbe9` |
| 1B | `services/api/src/claimant/invitation-address-v1.ts` | `645956fcc07bfd2e9d254236d564c13a1de79f2ba3025c7939716edd43db6e73` |

## Supporting Specifications And Evidence

- `docs/superpowers/specs/2026-08-04-claimant-slice-1b-native-bootstrap-handoff.md`
- `docs/superpowers/specs/2026-08-04-claimant-slice-1b-possession-proof-review-pack.md`
- `docs/superpowers/specs/2026-08-04-claimant-slice-1c-app-attest-contract.md`
- `docs/verification/2026-08-04-native-enrollment-contract.md`
- `docs/verification/2026-08-04-native-enrollment-possession-proof-review-pack.md`
- `docs/verification/2026-08-04-slice-1b-internal-adversarial-review.md`
- `docs/verification/2026-08-04-app-attest-contract.md`
- `docs/verification/2026-08-04-ios-secure-enclave-probe-harness.md`
- `docs/verification/2026-08-04-physical-iphone-custody-probe-build.md`

Documentation describes the review scope but is excluded from the code aggregates to avoid recursive hashes. Reviewers must identify the exact documentation revision they reviewed in their decision.

## Reproduction Commands

Run from the repository root using the repository-pinned dependencies:

```text
npm --workspace @vault/shared-types test -- --run src/claim/native-enrollment/validation.test.ts src/claim/native-enrollment/possession-proof-vector.test.ts src/claim/native-enrollment/app-attest-validation.test.ts src/claim/native-enrollment/app-attest-vector.test.ts
npm --workspace @vault/mobile test -- --run src/features/claimant-custody/native-enrollment-contract.test.ts src/features/claimant-custody/app-attest-contract.test.ts
npm --workspace @vault/api test -- --run src/claimant/native-enrollment-contract.test.ts src/claimant/invitation-address-v1.test.ts src/claimant/app-attest-contract.test.ts
npm run check:claim-vectors
npm run check:claim-vector-isolation
npm run check:claim-custody-isolation
npm run typecheck
npm run lint
```

The reviewer must also reproduce the P-256/HKDF/HMAC and App Attest client-data/key-ID-digest vectors independently without importing repository generator/helper code.

## Current Verification Snapshot

- Mobile: 422 passed and 3 existing skipped.
- Web: 150 passed.
- Shared types: 126 passed.
- Shared validation: 42 passed.
- API: 81 passed.
- Typechecks, full lint, security guards, GitHub Actions security, mobile secret scan, vector reproducibility/isolation, custody isolation, and `git diff --check` passed.
- No database suite is asserted for Slice 1B/1C because no live challenge persistence, route, migration, or transaction exists.
